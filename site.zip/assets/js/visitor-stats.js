(() => {
  const stats = document.querySelector('[data-visitor-stats]');
  if (!stats || stats.dataset.started) return;
  if (window.location.hostname !== stats.dataset.siteHost) {
    stats.remove();
    return;
  }
  stats.dataset.started = 'true';

  const status = stats.querySelector('[data-visitor-status]');
  const counters = ['site_pv', 'site_uv'].map(name => ({
    container: document.getElementById(`busuanzi_container_${name}`),
    value: document.getElementById(`busuanzi_value_${name}`)
  }));
  status.textContent = 'Page views / Visitors: Loading…';

  let complete = false;
  const unavailable = () => {
    if (!complete) status.textContent = 'Page views / Visitors: Temporarily unavailable';
  };
  const timeout = window.setTimeout(unavailable, 12000);
  // The provider's script load is not the count response. Wait for actual values.
  const observer = new MutationObserver(() => {
    const ready = counters.map(({ container, value }) => {
      const valid = /^\d+$/.test(value.textContent.trim());
      container.style.display = valid ? 'inline' : 'none';
      return valid;
    });
    if (!ready.every(Boolean)) return;
    complete = true;
    status.hidden = true;
    window.clearTimeout(timeout);
    observer.disconnect();
  });
  counters.forEach(({ value }) => observer.observe(value, {
    childList: true, characterData: true, subtree: true
  }));

  const script = document.createElement('script');
  script.src = 'https://busuanzi.ibruce.info/busuanzi/2.3/busuanzi.pure.mini.js';
  script.async = true;
  script.onerror = unavailable;
  // Do not retry automatically: another provider request can count a visit twice.
  document.head.appendChild(script);
})();
