(() => {
  const stats = document.querySelector('[data-visitor-stats]');
  if (!stats || window.location.hostname !== stats.dataset.siteHost) return;

  const script = document.createElement('script');
  script.src = 'https://busuanzi.ibruce.info/busuanzi/2.3/busuanzi.pure.mini.js';
  script.async = true;
  document.head.appendChild(script);
})();
